-- MySQL dump 10.13  Distrib 5.7.23, for Linux (x86_64)
--
-- Host: localhost    Database: irs_cloud
-- ------------------------------------------------------
-- Server version	5.7.23-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('admin','3a0b1273663343adfbe61a25954fd50b2c4ca6d3592c1d8d04de170e6a7eb2ed');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_registration`
--

DROP TABLE IF EXISTS `package_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_choice` varchar(15) NOT NULL,
  `person_name` varchar(50) NOT NULL,
  `person_address` text,
  `person_city` varchar(30) DEFAULT NULL,
  `person_phone` varchar(20) NOT NULL,
  `person_email` varchar(50) DEFAULT NULL,
  `business_name` varchar(50) NOT NULL,
  `business_slogan` text,
  `business_address` text,
  `business_phone` varchar(20) NOT NULL,
  `app_logo_path` varchar(255) DEFAULT NULL,
  `app_color_theme` varchar(10) DEFAULT NULL,
  `status` varchar(15) DEFAULT 'PENDING',
  `referal` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_registration`
--

LOCK TABLES `package_registration` WRITE;
/*!40000 ALTER TABLE `package_registration` DISABLE KEYS */;
INSERT INTO `package_registration` VALUES (1,'premium','Ahmad Ali Abdilah','Universe','Bali','081703744696','ahmad@gmail.com','asdfasd','','qweqdsd','12315123123','180814100742pm_asdfasd.jpg','#3519a8','DONE','ssavadssf'),(2,'premium','sdfasdf','','','adfafd','','adsfas','','','adfasfd','180814100952pm_adsfas.jpg','','DONE','');
/*!40000 ALTER TABLE `package_registration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-15  1:09:45
