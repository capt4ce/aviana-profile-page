<div class="aviana-footer">
    <div class="aviana-footer-first">
      <div class="container">
        <div class="row">

          <div class="col-md-6">
            <b>CUSTOMER SERVICE</b>
            <br/>
            <br/>
            <p>PT Aviana Sinar Abadi
              <br/> Jl. diponogoro No.109 Wisma Indovision, Denpasar Barat.
              <br/>Dauh Puri Klod, MNC Bank. 80119</p>
            <p>Phone 1 : &#09;
              <b>(0361) 232045</b>
              <br/>Phone 2 : &#09;
              <b>(0361) 229289</b>
            </p>
          </div>
          <div class="col-md-6 text-md-right text-sm-center">
            <div class="d-inline-block">
              <a href="#">
                <b>CARA KERJA</b>
              </a>
            </div>
            <div class="d-inline-block">
              <a href="#">
                <b>PRICING</b>
              </a>
            </div>
            <div class="d-inline-block">
              <a href="#">
                <b>SUPPORT</b>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="aviana-footer-second">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <p>Copyright &copy; <?php echo Date("Y");?>
              <b>IRS-CLOUD</b>
            </p>
          </div>
          <div class="col-sm-6 aviana-footer-logo">
            <img src="/IRS-CLOUD.png" height="25" class="img-responsive float-md-right" />
          </div>
        </div>
      </div>
    </div>
  </div>

<?php require_once('foot.php')?>
